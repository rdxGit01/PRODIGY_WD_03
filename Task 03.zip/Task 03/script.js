const board = document.getElementById("board");
let cells = [];
let currentPlayer = "X";

function checkWinner() {
  const winPatterns = [
    [0,1,2],[3,4,5],[6,7,8],
    [0,3,6],[1,4,7],[2,5,8],
    [0,4,8],[2,4,6]
  ];
  for (let pattern of winPatterns) {
    const [a,b,c] = pattern;
    if (
      cells[a].innerText &&
      cells[a].innerText === cells[b].innerText &&
      cells[a].innerText === cells[c].innerText
    ) {
      document.getElementById("result").innerText = `${cells[a].innerText} wins!`;
      board.removeEventListener("click", handleClick);
    }
  }
}

function handleClick(e) {
  const cell = e.target;
  if (cell.innerText === "") {
    cell.innerText = currentPlayer;
    checkWinner();
    currentPlayer = currentPlayer === "X" ? "O" : "X";
  }
}

function resetGame() {
  board.innerHTML = "";
  cells = [];
  for (let i = 0; i < 9; i++) {
    const cell = document.createElement("div");
    cell.classList.add("cell");
    board.appendChild(cell);
    cells.push(cell);
  }
  currentPlayer = "X";
  document.getElementById("result").innerText = "";
  board.addEventListener("click", handleClick);
}

resetGame();
